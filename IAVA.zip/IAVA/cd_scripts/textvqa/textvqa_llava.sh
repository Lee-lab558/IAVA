#!/bin/bash
test=vcd1
gpus=6
export CUDA_VISIBLE_DEVICES=${gpus}

python /sda/gaodh/projects/AvisC_copy/experiments/eval/model_vqa_loader_llava.py \
    --model-path /sda/gaodh/projects/Prompt-Highlighter/checkpoints/llava-v1.5-7b \
    --question-file /sda/gaodh/projects/Prompt-Highlighter/base_models/LLaVA/playground/data/eval/textvqa/llava_textvqa_val_v051_ocr.jsonl \
    --image-folder /sda/gaodh/projects/Prompt-Highlighter/base_models/LLaVA/playground/data/eval/textvqa/train_images \
    --answers-file /sda/gaodh/projects/AvisC_copy/textvqa_answers/${test}/${test}.jsonl \
    --temperature 1.0 \
    --conv-mode llava_v1

python /sda/gaodh/projects/AvisC_copy/experiments/eval/eval_textvqa.py \
    --annotation-file /sda/gaodh/projects/Prompt-Highlighter/base_models/LLaVA/playground/data/eval/textvqa/TextVQA_0.5.1_val.json \
    --result-file /sda/gaodh/projects/AvisC_copy/textvqa_answers/${test}/${test}.jsonl
